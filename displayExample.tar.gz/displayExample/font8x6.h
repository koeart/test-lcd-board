#ifndef _FONT8X6_H
#define _FONT8X6_H

#include <avr/pgmspace.h>

//*****************************************************************************
// 
extern prog_uint8_t font8x6[128][6];

#endif
